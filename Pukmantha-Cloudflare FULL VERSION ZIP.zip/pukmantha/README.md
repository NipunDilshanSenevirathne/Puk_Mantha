# Pukමන්තා

A cartoon 3D browser game for up to four friends. Choose from thirteen named photo-face characters, share a room code, and propel a raft with very questionable teamwork. Play Free Sailing, Time Trial or Team Race across three original courses. Includes mobile, keyboard and standard gamepad controls, beans, adjustable thrust, fart effects, emotes, local achievements, raft trims and opt-in voice chat. Players open the website; no Steam account, Steam client or game installation is required.

## Deploy the complete game to Cloudflare

**Extract the ZIP, then run `DEPLOY.cmd` inside its `pukmantha` folder on Windows.** Install [Node.js 22 or newer](https://nodejs.org/) first. The helper installs the locked dependencies, runs tests, opens Cloudflare login, builds the game, and deploys the website and multiplayer server together. Keep the window open until Wrangler prints your public HTTPS address.

The ZIP includes all source, a prebuilt `dist` folder, the original supplied soundtracks, the character textures, tests, and the Cloudflare configuration. It contains no account credentials. No custom domain or separately hosted server is required. You need your own Cloudflare account and an internet connection for deployment.

**This is a Cloudflare Workers project, not a Pages drag-and-drop ZIP.** Dropping only the website files into a static uploader cannot install the Durable Object that coordinates multiplayer rooms. `DEPLOY.cmd` handles that deployment using the included `wrangler.jsonc`; there are no bindings to configure by hand. Cloudflare documents the [combined Worker and static-assets deployment](https://developers.cloudflare.com/workers/static-assets/) and the [separate Worker required for Durable Objects in Pages](https://developers.cloudflare.com/pages/functions/bindings/#durable-objects).

### macOS / Linux

After extracting, open a terminal in `pukmantha` and run:

```sh
sh DEPLOY.sh
```

### Manual commands / PowerShell

Open a terminal in the folder containing `package.json`:

```sh
npm ci
npm test
npx wrangler login
npm run deploy
```

If PowerShell blocks `npm.ps1`, use `npm.cmd` and `npx.cmd` in those commands, or use the Windows helper. The deployment name defaults to `pukmantha`. If that name already belongs to a different project in your account, change only `name` in `wrangler.jsonc` before deployment. Keep the `ROOMS` binding, `GameRoom` class, and `v1` migration intact. Updates deploy to the same Worker name and account.

Wrangler prints a URL like `https://pukmantha.YOUR-SUBDOMAIN.workers.dev`. Open that URL on every phone and computer. Share it or the room invite link; users can join from different networks. The earlier temporary preview URL is not required.

To use the included prebuilt browser assets without rebuilding, run `npm ci`, log in, then `npm run deploy:prebuilt`. Deployment still bundles the server and configures its Durable Object. After changing any source, use the normal build-and-deploy route.

### Deploy through a Git-connected Cloudflare project

Put the extracted project in your Git repository. Connect it as a **Workers** application. Select the folder containing `package.json` as the root directory, use `npm run build` as the build command, and `npx wrangler deploy` as the deploy command. The included Wrangler config points to `dist` and declares the required room binding and migration. Do not select Pages static upload.

## Voice chat across different networks

Game synchronization uses the Worker and does not need TURN. Voice uses WebRTC between players with in-room signaling. The default STUN fallback can work on compatible networks, but cannot guarantee voice through every carrier, NAT or firewall.

For reliable cross-network voice, create a **Cloudflare Realtime TURN key** in your Cloudflare account, then run these commands from this project after deploying:

```sh
npx wrangler secret put TURN_KEY_ID
npx wrangler secret put TURN_API_TOKEN
```

Paste the TURN key identifier into the first prompt and that key's API token into the second. Keep these values out of source files and browser code. The Worker exchanges them for short-lived ICE credentials and only provides those to joined room members. See [Cloudflare's TURN credential instructions](https://developers.cloudflare.com/realtime/turn/generate-credentials/).

Open a new room afterward, enable voice, allow microphone access, and test with a second device on a different network. Microphones need HTTPS (localhost is the development exception). The game does not record voices. Phones may pause audio when the browser is backgrounded or the screen is locked. The supplied project does not include a funded TURN account or credentials; actual microphone audio across real devices and carrier networks must be checked in your deployment. Cloudflare Worker/Durable Object usage and TURN usage are subject to your account's limits and billing.

## Play locally

```sh
npm ci
npm run dev
```

Open `http://localhost:8787`. The local server supports solo practice and multiple browser sessions. The localhost address is only available on the current computer; deploy for friends in other locations.

1. Pick a character and course.
2. Choose solo practice, or create a room and share its code/invite link.
3. In multiplayer, at least two connected players are needed. Guests press Ready; the host starts.
4. Aim with WASD or arrow keys and hold Space to fart. These are the defaults; keyboard bindings can be changed in settings. Phones use the direction controls and FART button.
5. Aim points in the direction of travel. Opposing thrust cancels; coordinate to avoid obstacles and reach the finish.

All characters have equal abilities. Voice is opt-in. Use the sound settings to adjust background music, game effects and voices. Browser audio starts after interaction. The supplied loss track plays on defeat; it stops on retry or exit.

## Modes, controls and progression

| Mode | How it works |
| --- | --- |
| Free Sailing | Explore without a countdown. Hull damage still matters: rocks and riverbanks can sink the raft. Reach the finish to complete the course. |
| Time Trial | Reach the finish before the course timer runs out. Successful finishes can set a best time stored on this browser. Records are separated by course and crew size, so solo and four-person runs are tracked separately. |
| Team Race | Two teams race separate rafts: 1v1 with two people, or 2v2 with four people. Rival rafts are ghosts to one another and do not collide; each must still navigate the obstacles and protect its own hull. The room limit remains four people. |

Solo practice uses the single-raft modes. Team Race needs a multiplayer room with an even, balanced crew. The host chooses the shared mode and course before starting. Free Sailing removes the clock, not the need to steer.

- **Thrust:** choose 0.6×, 1× or 1.4× power. Greater thrust uses more gas per blast; regeneration and bean pickups still matter.
- **Keyboard:** default WASD aim, Space fires, and V toggles your microphone. Rebind these actions in settings; conflicting bindings and modifier-only keys are rejected. Arrow keys always remain available for aiming. Reset restores the defaults.
- **Phone/tablet:** use the on-screen direction pad and hold FART. Release the button to stop firing. Landscape gives the controls more space.
- **Gamepad:** standard browser-mapped controllers use the left stick or D-pad to aim, and A or the right trigger to fire. Connect the controller and press a button to let the browser recognize it. Nonstandard mappings are not assumed. Release a held fire button after returning from a menu before firing again.
- **Camera:** adjust camera distance in settings to choose a closer or wider view. Reduced motion is available alongside the audio settings.
- **Achievements and raft trims:** local badges record milestones. A first finish unlocks a raft trim, and completing all three courses unlocks another. The achievement display shows the available progression.

Best times, achievements, unlocked trims, bindings and preferences are stored locally in this browser. They do not transfer between devices or browser profiles, are not shared room leaderboards, and can disappear if site data is cleared. They require no account. Private browsing or blocked storage may prevent persistence. Local best times are personal records rather than a tamper-proof competitive ranking.

## Included assets and code

- Character names match the supplied filenames without `.jpg`; the photos supply the face pixels and the bodies are custom cartoon models. Face regions are masked for display; source JPGs remain in the package as textures.
- `public/assets/background.mp3` is the supplied background soundtrack.
- `public/assets/lose.mp3` is the supplied defeat soundtrack.
- Fart sound effects are generated by Web Audio.
- Three.js is bundled locally; its license is included at `dist/licenses/three.txt`.
- The lagoon illustration at `public/assets/lagoon-hero.png` is original artwork created for this project using OpenAI image generation.
- The three course SVG illustrations are original project artwork: `course-bay.svg`, `course-rapids.svg` and `course-flush.svg`.
- Fredoka, Manrope, Noto Sans Sinhala and Nunito were sourced from Google Fonts and are self-hosted under `public/assets/fonts/`. Each font's SIL Open Font License is included beside its font file as `*-OFL.txt` and copied into the deployed build. The page does not need a live Google Fonts connection.
- The user-supplied design report, Figma reference and Steam example were design inspirations. This is an original implementation rather than an exact clone; its supplied employee photos and soundtracks come from the user. No Steam runtime or reference-game assets are included.

| Path | Purpose |
| --- | --- |
| `src/client.js` | Menus, room connections, sound, progression and game flow |
| `src/controls.js` | Rebindable keyboard, touch state and standard gamepad input |
| `src/render.js` | 3D world, cartoon characters and face textures |
| `src/shared.js` | Character roster, course definitions and physics |
| `src/worker.js` | Multiplayer rooms, WebSocket protocol and TURN credentials |
| `src/voice.js` | WebRTC audio and microphone controls |
| `public/` | Home page, styles, images and soundtracks |
| `dist/` | Prebuilt browser files deployed with the Worker |
| `wrangler.jsonc` | Cloudflare Worker, asset binding and Durable Object migration |
| `tests/` | Physics, room protocol, client lifecycle, controls and WebRTC regression tests |

## Verify before deploying an update

```sh
npm run check
```

This runs unit tests, makes a fresh browser build, checks required assets and local HTML/CSS references, and performs a Wrangler deployment dry run. The asset check also verifies that the redesign, landing script, lagoon art, all course SVGs, self-hosted fonts and their licenses are present and nonempty. It does **not** publish anything. To exercise real WebSockets locally, leave `npm run dev` running and execute this in a second terminal:

```sh
npm run test:rooms
```

To target your deployed version, set `GAME_ORIGIN` to the HTTPS origin before running the integration test. In PowerShell:

```powershell
$env:GAME_ORIGIN = 'https://pukmantha.YOUR-SUBDOMAIN.workers.dev'
npm run test:rooms
```

The integration test creates temporary test rooms. Automated checks do not substitute for physical phone, live microphone or long-duration load tests. No software release can promise that every possible bug has been eliminated.

### Produce another complete ZIP

```sh
npm run package
```

Creates `Pukmantha-Cloudflare.zip` and its SHA-256 checksum next to the project folder. The package includes source, prebuilt assets and deployment helpers, with a `CHECKSUMS.sha256` manifest inside. It deliberately excludes `node_modules`, `.wrangler`, environment secrets, local credentials and logs. Run `npm ci` after extracting to reinstall the pinned dependencies. The dependency-free archive script uses a stable file order and timestamp.

## Troubleshooting

| Symptom | Action |
| --- | --- |
| Home page opens, but rooms fail | Deploy the entire Workers project. A static-only `dist` upload has no multiplayer server. |
| Wrangler requests an account | Complete the browser login and select your own account when prompted. |
| Authentication or permissions error | Run `npx wrangler login` again using an account allowed to deploy Workers and Durable Objects. |
| No sound | Tap a play button first, then check the game's audio controls and the device mute setting. |
| Microphone denied | Enable microphone permission for the deployed HTTPS site in browser settings. |
| Voice works at home but fails on mobile data | Configure the two TURN secrets and test a new room on different networks. |
| Room expired after a server update | Rooms are ephemeral. Create a new room and share its new code. |
| Personal records or unlocked trims are missing | Use the same browser profile and site address; progression is local and can be removed by clearing site data. |
| Controller is not responding | Use a standard-mapped controller, press a controller button after opening the page, and ensure no settings dialog or text field has focus. |
| Dependencies fail to install | Check that Node.js is version 22 or newer and the package registry is reachable; rerun `npm ci`. |

## Operational scope

One live room supports four players. Rooms are ephemeral and are reset by deployment or server restarts; active crews should finish before updating the Worker. The game has no accounts, server-side progression, durable global leaderboards, voice recordings or public room listings. Personal records and unlocks exist only in browser storage. Its server-authoritative raft simulation is rendered in 3D in each browser. Team Race keeps a separate authoritative raft for each team. Checkpoints repair the raft rather than creating a saved respawn point. Do not use a temporary development deployment as permanent hosting. Keep your Cloudflare account and optional TURN service configured for ongoing play.
